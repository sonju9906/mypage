@echo off
:: ============================================================
::  HairMatch - start both servers in two windows
::    window 1 : inference (HairFastGAN, GPU)  port 8001
::    window 2 : web (FastAPI + static pages)   port 8000
::  Put this file in D:\hairMatch_demo2 (same folder as setup_env.bat)
:: ============================================================
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"

start "HairMatch-inference 8001" cmd /k "call "%ROOT%\setup_env.bat" && cd /d "%ROOT%\inference" && python infer_server.py"

:: give the GPU server a head start so web_main sees it on startup
timeout /t 5 /nobreak >nul

start "HairMatch-web 8000" cmd /k "call "%ROOT%\web\run_web.bat""

echo Started. Open http://127.0.0.1:8000 after both windows finish loading.
