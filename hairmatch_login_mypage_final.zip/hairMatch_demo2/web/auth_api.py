"""
auth_api.py — 회원가입 · 로그인 · 로그아웃 (서버 계정)

붙이는 법 (다른 라우터와 같다)
    from auth_api import router as auth_router
    app.include_router(auth_router)

화면
    static/log.html      로그인
    static/signin.html   회원가입
    static/auth.js       모든 화면이 공통으로 쓰는 로그인 상태 표시 · 로그아웃

저장 위치
    PostgreSQL (db_setup_v2.py 의 DATABASE_URL) — users, user_sessions 테이블.
    먼저 python db_setup_v2.py 를 한 번 돌려 테이블을 만든다.

API  (에러 형식은 a.html 과 같다: {"error": {"code": "..."}})
    POST   /auth/signup    JSON {email, password, name, agree}   → 가입 후 바로 로그인
    POST   /auth/login     JSON {email, password}
    POST   /auth/logout
    GET    /auth/me        → {"logged_in": bool, "name", "email", "created_at"}
    POST   /auth/password  JSON {current, new}                   비밀번호 변경
    DELETE /auth/account   JSON {password}                       회원 탈퇴 (기록·사진도 삭제)

사용자 식별 — 다른 파일이 쓰는 함수
    current_user(request)  → 로그인한 User 또는 None
    current_owner(request) → Owner(user_id=회원번호) 또는 Owner(guest_id=브라우저 쿠키 hm_uid)
    로그인하는 순간 그 브라우저의 게스트 기록(분석 기록·저장 사진)은 계정으로 옮겨진다.

보안
    - 비밀번호는 PBKDF2-SHA256(31만 회) + 사용자별 salt 로만 저장한다. 원문은 어디에도 남지 않는다.
    - 세션 토큰은 DB 에 SHA-256 해시로만 둔다. DB 가 새도 토큰을 쓸 수 없다.
    - 쿠키 hm_session: HttpOnly(자바스크립트가 못 읽음), SameSite=Lax.
      ★ https 로 배포하면 COOKIE_SECURE=1 환경변수를 켤 것.
    - 같은 이메일로 10분에 5번 틀리면 잠시 막는다.
    - 로그인 실패 메시지는 '이메일이 없음/비번 틀림'을 구분하지 않는다(가입 여부 노출 방지).
"""

import hashlib
import hmac
import os
import re
import secrets
import time
from dataclasses import dataclass
from datetime import timedelta
from typing import Optional

from sqlalchemy import delete, select
from sqlalchemy.exc import IntegrityError

from db_setup_v2 import User, UserSession, get_session, utcnow

SESSION_COOKIE = "hm_session"
GUEST_COOKIE = "hm_uid"                    # gemini_api / mypage_api 와 같은 게스트 쿠키
SESSION_DAYS = 14
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "0") == "1"
PBKDF2_ITER = 310_000
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]+\.[A-Za-z]{2,}$")
MAX_FAILS, FAIL_WINDOW = 5, 600            # 10분에 5번

_fails: dict = {}                          # email → [실패 시각, ...]  (서버 재시작 시 초기화)


# ═════════════════════════ 누가 쓰고 있나 ═════════════════════════
@dataclass(frozen=True)
class Owner:
    """기록·사진의 주인. 회원이면 user_id, 로그인 전이면 guest_id(브라우저 쿠키)."""
    user_id: Optional[int] = None
    guest_id: Optional[str] = None

    def __bool__(self) -> bool:
        return bool(self.user_id or self.guest_id)

    def where(self, model):
        """select(Model).where(owner.where(Model)) 처럼 쓴다."""
        return (model.user_id == self.user_id) if self.user_id else (model.guest_id == self.guest_id)

    def cols(self) -> dict:
        """새 행을 만들 때 Model(**owner.cols(), ...)"""
        return {"user_id": self.user_id, "guest_id": None} if self.user_id \
            else {"user_id": None, "guest_id": self.guest_id}


# ═════════════════════════ 순수 함수 (세션 s 를 받는다) ═════════════════════════
def hash_password(pw: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, PBKDF2_ITER)
    return f"pbkdf2_sha256${PBKDF2_ITER}${salt.hex()}${dk.hex()}"


def check_password(pw: str, stored: str) -> bool:
    try:
        _, it, salt, h = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), int(it))
        return hmac.compare_digest(dk.hex(), h)
    except (ValueError, TypeError):
        return False


_DUMMY_HASH = hash_password("dummy-for-timing1")


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def norm_email(email: str) -> str:
    return (email or "").strip().lower()


def validate_password(pw: str) -> Optional[str]:
    if not (8 <= len(pw or "") <= 128) or not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw):
        return "WEAK_PASSWORD"            # 8자 이상, 영문 + 숫자 (signin.html 과 같은 규칙)
    return None


def validate_signup(email: str, password: str, name: str) -> Optional[str]:
    if not EMAIL_RE.match(email) or len(email) > 254:
        return "INVALID_EMAIL"
    if not (1 <= len((name or "").strip()) <= 20):
        return "INVALID_NAME"
    return validate_password(password)


def create_user(s, email: str, password: str, name: str):
    """(User, None) 또는 (None, 에러코드). commit 은 부르는 쪽이 한다."""
    email = norm_email(email)
    err = validate_signup(email, password, name)
    if err:
        return None, err
    if s.scalar(select(User.id).where(User.email == email)) is not None:
        return None, "EMAIL_TAKEN"
    user = User(email=email, name=name.strip(), pw_hash=hash_password(password), created_at=utcnow())
    s.add(user)
    try:
        s.flush()                          # id 를 받는다. 동시에 같은 이메일이 들어오면 여기서 막힌다
    except IntegrityError:
        s.rollback()
        return None, "EMAIL_TAKEN"
    return user, None


def authenticate(s, email: str, password: str) -> Optional[User]:
    user = s.scalar(select(User).where(User.email == norm_email(email)))
    if user is None:
        check_password(password, _DUMMY_HASH)          # 없는 이메일도 같은 시간이 걸리게
        return None
    return user if check_password(password, user.pw_hash) else None


def new_session(s, user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    s.execute(delete(UserSession).where(UserSession.expires_at < utcnow()))     # 만료된 것 청소
    s.add(UserSession(token_hash=token_hash(token), user_id=user_id,
                      expires_at=utcnow() + timedelta(days=SESSION_DAYS)))
    return token


def session_user(s, token: Optional[str]) -> Optional[User]:
    if not token:
        return None
    return s.scalar(
        select(User).join(UserSession, UserSession.user_id == User.id)
        .where(UserSession.token_hash == token_hash(token), UserSession.expires_at > utcnow()))


def end_session(s, token: Optional[str]) -> None:
    if token:
        s.execute(delete(UserSession).where(UserSession.token_hash == token_hash(token)))


def change_password(s, user: User, current: str, new: str, keep_token: Optional[str] = None) -> Optional[str]:
    """성공하면 None. 다른 기기의 로그인은 끊고 keep_token(지금 기기)만 남긴다."""
    if not check_password(current, user.pw_hash):
        return "WRONG_PASSWORD"
    err = validate_password(new)
    if err:
        return err
    user.pw_hash = hash_password(new)
    q = delete(UserSession).where(UserSession.user_id == user.id)
    if keep_token:
        q = q.where(UserSession.token_hash != token_hash(keep_token))
    s.execute(q)
    return None


def delete_user(s, user_id: int) -> None:
    """세션과 회원 행을 지운다. 기록·사진은 mypage_api.wipe() 가 먼저 지운다."""
    s.execute(delete(UserSession).where(UserSession.user_id == user_id))
    s.execute(delete(User).where(User.id == user_id))


def too_many_fails(email: str) -> bool:
    now = time.time()
    lst = [t for t in _fails.get(email, []) if now - t < FAIL_WINDOW]
    _fails[email] = lst
    return len(lst) >= MAX_FAILS


def note_fail(email: str) -> None:
    _fails.setdefault(email, []).append(time.time())


# ═════════════════════════ 요청에서 사용자 찾기 ═════════════════════════
def current_user(request) -> Optional[User]:
    with get_session() as s:
        return session_user(s, request.cookies.get(SESSION_COOKIE))


def current_owner(request, user: Optional[User] = None) -> Owner:
    """회원이면 Owner(user_id), 아니면 Owner(guest_id). 쿠키가 하나도 없으면 빈 Owner."""
    user = user if user is not None else current_user(request)
    if user:
        return Owner(user_id=user.id)
    return Owner(guest_id=request.cookies.get(GUEST_COOKIE))


# ═════════════════════════ 라우트 ═════════════════════════
from fastapi import APIRouter, Request                    # noqa: E402
from fastapi.responses import JSONResponse                # noqa: E402
from pydantic import BaseModel, Field                     # noqa: E402

router = APIRouter()


class SignupIn(BaseModel):
    email: str = Field(..., max_length=254)
    password: str = Field(..., max_length=128)
    name: str = Field(..., max_length=20)
    agree: bool = False


class LoginIn(BaseModel):
    email: str = Field(..., max_length=254)
    password: str = Field(..., max_length=128)


class PasswordIn(BaseModel):
    current: str = Field(..., max_length=128)
    new: str = Field(..., max_length=128)


class DeleteIn(BaseModel):
    password: str = Field(..., max_length=128)


def _err(status: int, code: str) -> JSONResponse:
    return JSONResponse(status_code=status, content={"error": {"code": code}})


def _me_json(u: User) -> dict:
    return {"logged_in": True, "name": u.name, "email": u.email,
            "created_at": u.created_at.isoformat(timespec="seconds") + "Z"}


def _login(s, request: Request, user: User, status: int = 200) -> JSONResponse:
    """세션을 만들고, 이 브라우저의 게스트 기록을 계정으로 옮기고, 한 번에 commit."""
    from mypage_api import merge_guest      # 순환 import 를 피하려고 여기서 부른다
    guest = request.cookies.get(GUEST_COOKIE)
    if guest:
        merge_guest(s, guest, user.id)
    token = new_session(s, user.id)
    s.commit()
    resp = JSONResponse(status_code=status, content=_me_json(user), headers={"Cache-Control": "no-store"})
    resp.set_cookie(SESSION_COOKIE, token, max_age=SESSION_DAYS * 86400,
                    httponly=True, samesite="lax", secure=COOKIE_SECURE)
    return resp


@router.post("/auth/signup")
async def signup(body: SignupIn, request: Request):
    if not body.agree:
        return _err(400, "AGREE_REQUIRED")
    with get_session() as s:
        user, err = create_user(s, body.email, body.password, body.name)
        if err:
            return _err(409 if err == "EMAIL_TAKEN" else 400, err)
        return _login(s, request, user, 201)


@router.post("/auth/login")
async def login(body: LoginIn, request: Request):
    email = norm_email(body.email)
    if too_many_fails(email):
        return _err(429, "TOO_MANY_ATTEMPTS")
    with get_session() as s:
        user = authenticate(s, email, body.password)
        if user is None:
            note_fail(email)
            return _err(401, "BAD_CREDENTIALS")
        _fails.pop(email, None)
        return _login(s, request, user)


@router.post("/auth/logout")
async def logout(request: Request):
    with get_session() as s:
        end_session(s, request.cookies.get(SESSION_COOKIE))
        s.commit()
    resp = JSONResponse(content={"logged_in": False})
    resp.delete_cookie(SESSION_COOKIE)
    return resp


@router.get("/auth/me")
async def me(request: Request):
    u = current_user(request)
    return JSONResponse(content=_me_json(u) if u else {"logged_in": False},
                        headers={"Cache-Control": "no-store"})


@router.post("/auth/password")
async def password(body: PasswordIn, request: Request):
    token = request.cookies.get(SESSION_COOKIE)
    with get_session() as s:
        u = session_user(s, token)
        if not u:
            return _err(401, "NOT_LOGGED_IN")
        err = change_password(s, u, body.current, body.new, keep_token=token)
        if err:
            return _err(400, err)
        s.commit()
    return {"changed": True}


@router.delete("/auth/account")
async def delete_account(body: DeleteIn, request: Request):
    from mypage_api import wipe
    with get_session() as s:
        u = session_user(s, request.cookies.get(SESSION_COOKIE))
        if not u:
            return _err(401, "NOT_LOGGED_IN")
        if not check_password(body.password, u.pw_hash):
            return _err(400, "WRONG_PASSWORD")
        wipe(s, Owner(user_id=u.id))           # 기록·사진(파일 포함)·설정
        delete_user(s, u.id)
        s.commit()
    resp = JSONResponse(content={"deleted": True})
    resp.delete_cookie(SESSION_COOKIE)
    return resp
