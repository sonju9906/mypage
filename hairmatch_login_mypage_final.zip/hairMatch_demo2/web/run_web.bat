@echo off
:: ============================================================
::  HairMatch web server (port 8000)  -  run from any cmd window
::  Edit the 3 values below once, then just run: run_web.bat
:: ============================================================

:: 1) PostgreSQL connection (change PASSWORD to your postgres password)
set "DATABASE_URL=postgresql+psycopg2://postgres:PASSWORD@localhost:5432/hairmatch_db"
::    No PostgreSQL? Comment the line above (add ::) and use SQLite instead:
:: set "DATABASE_URL=sqlite:///hairmatch.db"

:: 2) Gemini key for "prompt generate" screen (leave empty if not used)
if not defined GEMINI_API_KEY set "GEMINI_API_KEY="

:: 3) Kakao REST key for salon search (leave empty if not used)
if not defined KAKAO_REST_KEY set "KAKAO_REST_KEY="

set "PGCLIENTENCODING=UTF8"
set "PYTHONUTF8=1"
cd /d "%~dp0"

if not exist "venv_web\Scripts\activate.bat" (
    echo [FAIL] venv_web not found in %~dp0
    exit /b 1
)
call "venv_web\Scripts\activate.bat"
echo [ OK ] venv_web activated

if not exist "face_shape_cnn.py" (
    echo [ .. ] face_shape_cnn.py missing - copying from 09_predict.py
    copy /y "09_predict.py" "face_shape_cnn.py" >nul
)

echo [ .. ] DB tables check (db_setup_v2.py)
python db_setup_v2.py >nul
if errorlevel 1 (
    echo [FAIL] DB setup failed. Check DATABASE_URL / PostgreSQL service.
    python db_setup_v2.py
    exit /b 1
)
echo [ OK ] DB ready

echo.
echo  Web    : http://127.0.0.1:8000
echo  Login  : http://127.0.0.1:8000/log.html
echo  MyPage : http://127.0.0.1:8000/mypage.html
echo.
python web_main.py
