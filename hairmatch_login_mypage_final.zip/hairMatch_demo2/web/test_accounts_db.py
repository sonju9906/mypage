"""
test_accounts_db.py — 회원 · 마이페이지 · 생성 횟수가 DB 와 제대로 동작하는지 한 번에 점검

    python test_accounts_db.py            # 임시 SQLite 로 점검 (PostgreSQL 필요 없음, 아무것도 안 남음)
    python test_accounts_db.py --pg       # 지금 DATABASE_URL(PostgreSQL)로 점검
                                          #   먼저 python db_setup_v2.py 를 돌려 둘 것
                                          #   ★ 하나의 트랜잭션 안에서만 돌리고 마지막에 되돌린다(rollback).
                                          #     실제 회원·기록은 하나도 바뀌지 않는다. 사진 파일도 임시 폴더에만.

결과: 항목마다 PASS / FAIL, 마지막에 'ALL PASS' 또는 실패 개수.
"""
import argparse
import io
import os
import sys
import tempfile
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--pg", action="store_true", help="DATABASE_URL 의 PostgreSQL 로 점검 (rollback)")
args = ap.parse_args()

tmp = Path(tempfile.mkdtemp(prefix="hm_test_"))
if not args.pg:
    os.environ["DATABASE_URL"] = f"sqlite:///{tmp / 'test.db'}"
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PIL import Image                                                     # noqa: E402
from sqlalchemy import func, select                                       # noqa: E402

import db_setup_v2 as D                                                   # noqa: E402
import auth_api as A                                                      # noqa: E402
import mypage_api as M                                                    # noqa: E402
import gemini_api as G                                                    # noqa: E402

FAILS = []


def check(cond, msg):
    print(("  PASS " if cond else "  FAIL ") + msg)
    if not cond:
        FAILS.append(msg)


def png(color=(200, 180, 160), size=(1600, 2000)):
    b = io.BytesIO()
    Image.new("RGB", size, color).save(b, "PNG")
    return b.getvalue()


masked = D.DATABASE_URL.split("@")[-1] if "@" in D.DATABASE_URL else D.DATABASE_URL
print(f"DB: {masked}\n")

s = D.get_session()
if args.pg:
    if not s.scalar(select(func.count()).select_from(D.FaceShape)):
        sys.exit("face_shapes 가 비어 있습니다. 먼저 python db_setup_v2.py 를 실행하세요.")
    s.execute(select(func.count()).select_from(D.User))       # 사용자 테이블이 없으면 여기서 에러
else:
    D.Base.metadata.create_all(s.get_bind())
    D.seed(s)                                                 # 얼굴형·스타일 기준 데이터
gen = tmp / "gen"
EMAIL = "selftest.hairmatch@example.com"

try:
    print("[회원가입 · 로그인]")
    check(A.create_user(s, "bad", "abcd1234", "a")[1] == "INVALID_EMAIL", "이메일 형식 검사")
    check(A.create_user(s, EMAIL, "short1", "a")[1] == "WEAK_PASSWORD", "비밀번호 8자 미만 거절")
    check(A.create_user(s, EMAIL, "onlyletters", "a")[1] == "WEAK_PASSWORD", "숫자 없는 비밀번호 거절")
    check(A.create_user(s, EMAIL, "abcd1234", " ")[1] == "INVALID_NAME", "빈 이름 거절")
    user, err = A.create_user(s, "  SelfTest.HairMatch@Example.com ", "abcd1234", "테스트")
    check(user is not None and err is None and user.email == EMAIL, "가입 성공 + 이메일 소문자 정규화")
    check(A.create_user(s, EMAIL.upper(), "abcd1234", "x")[1] == "EMAIL_TAKEN", "대소문자만 다른 이메일 중복 거절")
    check("abcd1234" not in user.pw_hash and user.pw_hash.startswith("pbkdf2_sha256$"), "비밀번호는 해시로만 저장")
    check(A.authenticate(s, EMAIL.upper(), "abcd1234").id == user.id, "로그인 성공")
    check(A.authenticate(s, EMAIL, "wrong1234") is None, "틀린 비밀번호 거절")
    check(A.authenticate(s, "nobody@example.com", "abcd1234") is None, "없는 이메일 거절")

    print("[세션]")
    tok = A.new_session(s, user.id); s.flush()
    check(A.session_user(s, tok).id == user.id, "세션으로 사용자 찾기")
    stored = s.scalar(select(D.UserSession.token_hash).where(D.UserSession.user_id == user.id))
    check(stored != tok and len(stored) == 64, "토큰 원문이 아니라 해시만 저장")
    check(A.session_user(s, "forged-token") is None, "가짜 토큰 거절")
    tok2 = A.new_session(s, user.id); s.flush()
    for row in s.scalars(select(D.UserSession).where(D.UserSession.token_hash == A.token_hash(tok2))):
        row.expires_at = D.utcnow().replace(year=2000)
    s.flush()
    check(A.session_user(s, tok2) is None, "만료된 세션 거절")
    A.end_session(s, tok); s.flush()
    check(A.session_user(s, tok) is None, "로그아웃하면 세션 사라짐")

    print("[비밀번호 변경]")
    t_keep, t_other = A.new_session(s, user.id), A.new_session(s, user.id); s.flush()
    check(A.change_password(s, user, "nope1234", "newpass99") == "WRONG_PASSWORD", "현재 비밀번호 틀리면 거절")
    check(A.change_password(s, user, "abcd1234", "weak") == "WEAK_PASSWORD", "약한 새 비밀번호 거절")
    check(A.change_password(s, user, "abcd1234", "newpass99", keep_token=t_keep) is None, "변경 성공")
    s.flush()
    check(A.authenticate(s, EMAIL, "newpass99") is not None, "새 비밀번호로 로그인")
    check(A.session_user(s, t_keep) is not None and A.session_user(s, t_other) is None,
          "지금 기기만 로그인 유지, 다른 기기는 해제")

    print("[게스트 기록 · 사진]")
    guest = A.Owner(guest_id="selftest_guest_cookie")
    other = A.Owner(guest_id="selftest_someone_else")
    res = {"gender": "female", "primary": {"code": "Oval", "name_ko": "계란형", "probability": .48},
           "is_ambiguous": True, "distribution": [{"code": "Oval", "name_ko": "계란형", "probability": .48},
                                                  {"code": "Round", "name_ko": "둥근형", "probability": .39}]}
    for _ in range(3):
        M.record_analysis(s, guest, res)
    h = M.list_history(s, guest)
    check(len(h) == 3 and h[0]["name_ko"] == "계란형" and h[0]["distribution"][1]["code"] == "Round",
          "분석 기록 저장 + 얼굴형 이름은 face_shapes 에서")
    check(h[0]["created_at"].endswith("Z"), "시각은 UTC 표시(Z) — 화면에서 한국 시간으로 보임")
    check(M.record_analysis(s, guest, {"face_shape": "Bad"}) is None, "이상한 얼굴형 코드는 저장 안 함")
    check(M.list_history(s, other) == [], "다른 사람 기록은 안 보임")
    check(not M.delete_history(s, other, h[0]["id"]), "다른 사람 기록은 못 지움")

    photo, err = M.record_photo(s, guest, "synth", "허쉬컷", png(), "hush", "Oval", "female", gen)
    check(photo is not None and err is None, "합성 사진 저장")
    out = Image.open(io.BytesIO(M.get_photo(s, guest, photo.id, gen)))
    check(out.format == "JPEG" and max(out.size) == 1024, "JPEG·긴 변 1024px 로 다시 저장 (메타데이터 제거)")
    lst = M.list_photos(s, guest)
    check(lst[0]["slug"] == "hush", "사진 → hairstyles 연결 (slug)")
    check(M.get_photo(s, other, photo.id, gen) is None, "다른 사람은 사진을 못 받음")
    check(M.record_photo(s, guest, "synth", "x", b"not an image", gen_dir=gen)[1] == "BAD_IMAGE", "이미지 아닌 파일 거절")
    check(M.record_photo(s, guest, "synth", "x", png(), "../../etc", gen_dir=gen)[1] == "INVALID", "이상한 slug 거절")
    check(M.record_photo(s, guest, "hack", "x", png(), gen_dir=gen)[1] == "INVALID", "모르는 종류 거절")
    p2, _ = M.record_photo(s, guest, "synth", "모르는 스타일", png(), "not_in_db", gen_dir=gen)
    check(p2 is not None and M.list_photos(s, guest)[0]["slug"] is None, "DB 에 없는 slug 는 연결 없이 저장")
    M.set_save_history(s, guest, False)
    check(M.record_analysis(s, guest, res) is None, "기록 저장 끄면 분석 기록 안 남음")

    print("[로그인하면 게스트 기록이 계정으로]")
    for _ in range(25):
        M.record_analysis(s, A.Owner(user_id=user.id), res)
    M.merge_guest(s, guest.guest_id, user.id); s.flush()
    me = A.Owner(user_id=user.id)
    check(len(M.list_photos(s, me)) == 2 and M.list_photos(s, guest) == [], "사진이 계정으로 옮겨짐")
    check(len(M.list_history(s, me)) == M.MAX_HISTORY and M.list_history(s, guest) == [],
          f"기록도 옮겨지고 최근 {M.MAX_HISTORY}건만 유지")
    prefs = s.scalars(select(D.VisitorPref).where((D.VisitorPref.user_id == user.id) |
                                                   (D.VisitorPref.guest_id == guest.guest_id))).all()
    check(len(prefs) == 1, "설정 행이 하나로 합쳐짐")
    summ = M.summary(s, me, user, G.FREE_LIMIT)
    check(summ["account"]["email"] == EMAIL and summ["photo_count"] == 2 and summ["guest_tag"] is None, "마이페이지 요약")

    print("[생성 횟수 (users.gen_used)]")
    r = [G.take_one(user.id, s) for _ in range(3)]
    s.refresh(user)
    check(r == [True, True, False] and user.gen_used == 2, "2회까지만 차감, 3번째는 거절")
    G.give_back(user.id, s); s.refresh(user)
    check(user.gen_used == 1, "실패하면 1회 되돌림")
    for _ in range(3):
        G.give_back(user.id, s)
    s.refresh(user)
    check(user.gen_used == 0, "0 밑으로 안 내려감")

    print("[삭제 · 탈퇴]")
    n_files = len(list(gen.iterdir()))
    M.wipe(s, me, gen); s.flush()
    check(M.list_photos(s, me) == [] and M.list_history(s, me) == [] and len(list(gen.iterdir())) == n_files - 2,
          "전체 삭제: 기록·사진·파일까지")
    A.delete_user(s, user.id); s.flush()
    check(A.authenticate(s, EMAIL, "newpass99") is None and A.session_user(s, t_keep) is None, "탈퇴 후 로그인 불가")
finally:
    s.rollback()                         # ★ 실제 DB 에는 아무것도 남기지 않는다
    s.close()

print()
print("ALL PASS" if not FAILS else f"{len(FAILS)}개 실패:\n  - " + "\n  - ".join(FAILS))
sys.exit(1 if FAILS else 0)
