"""
mypage_api.py — 마이페이지 API 라우터

붙이는 법 (salons_api.py, gemini_api.py 와 같다)
    from mypage_api import router as mypage_router, save_analysis
    app.include_router(mypage_router)

저장 위치
    PostgreSQL (db_setup_v2.py 의 DATABASE_URL) — visitor_prefs, analysis_history, saved_photos 테이블.
    사진 파일만 gen_store/ 폴더에 둔다 (static/ 밖이라 브라우저가 직접 열 수 없다).

화면
    static/mypage.html            http://localhost:8000/mypage.html
    계정 드롭다운의 네 메뉴가 각각 #account / #history / #saved / #security 로 온다.

API  (에러 형식은 a.html 과 같다: {"error": {"code": "..."}})
    GET    /me                       계정 정보 요약 (로그인 정보, 생성 남은 횟수, 개수, 설정)
    GET    /me/history               얼굴형 분석 기록 (최근순, 최대 20건)
    DELETE /me/history/{id}
    GET    /me/photos?kind=          저장한 사진. kind = synth(추천 합성) | prompt(프롬프트 생성) | 생략=전부
    POST   /me/photos                합성 결과 사진 저장 (multipart: file, slug, title, face_shape?, gender?)
    GET    /me/photos/{id}/image     사진 — 본인 것일 때만 내려간다
    DELETE /me/photos/{id}
    PATCH  /me/settings              JSON {save_history: bool}
    DELETE /me                       내 기록·사진 전부 삭제 (생성 횟수는 초기화하지 않음)

무엇을 저장하나
    - 업로드한 원본 얼굴 사진: 저장하지 않는다 (web_main.py 원칙 그대로)
    - 얼굴형 분석: 얼굴형 코드(→ face_shapes)·확률·성별·시각만
    - 사진: '합성 결과'만. a.html 의 [사진 저장] 을 누른 것(synth, → hairstyles 참조)과
            화면 4 에서 프롬프트로 만든 것(prompt, 자동 저장).
      다시 인코딩해 메타데이터(EXIF)를 지우고 긴 변 1024px JPEG 로 저장한다.

주인
    로그인했으면 user_id, 아니면 브라우저 쿠키 hm_uid 를 guest_id 로 쓴다 (auth_api.Owner).
    로그인하는 순간 auth_api 가 merge_guest() 로 게스트 행을 계정으로 옮긴다.
"""

import io
import re
import secrets
from datetime import datetime
from pathlib import Path
from typing import Optional

from sqlalchemy import delete, func, select, update
from sqlalchemy.orm import joinedload

from auth_api import GUEST_COOKIE, Owner, current_owner, current_user
from db_setup_v2 import (AnalysisHistory, FaceShape, Hairstyle, SavedPhoto, User,
                         VisitorPref, get_session, utcnow)

HERE = Path(__file__).resolve().parent
GEN_DIR = HERE / "gen_store"            # ★ static/ 밖. 브라우저가 직접 열 수 없어야 한다
COOKIE_AGE = 60 * 60 * 24 * 30
MAX_HISTORY = 20
MAX_PHOTOS = 30                         # 사용자가 누른 저장(synth) 기준 한도
MAX_UPLOAD = 8 * 1024 * 1024
MAX_SIDE = 1024
SLUG_RE = re.compile(r"^[a-z0-9_]{1,40}$")
FACE_SHAPES = {"Heart", "Oblong", "Oval", "Round", "Square"}
GENDERS = {"male", "female"}
KINDS = {"synth", "prompt"}


def iso(dt: Optional[datetime]) -> Optional[str]:
    """DB 에는 UTC 를 시간대 없이 넣는다 → 'Z' 를 붙여야 브라우저가 한국 시간으로 바꿔 보여 준다."""
    return dt.isoformat(timespec="seconds") + "Z" if dt else None


# ═════════════════════════ 순수 함수 (세션 s, 주인 owner 를 받는다) ═════════════════════════
def get_prefs(s, owner: Owner) -> VisitorPref:
    p = s.scalar(select(VisitorPref).where(owner.where(VisitorPref)))
    if p is None:
        p = VisitorPref(**owner.cols(), first_seen=utcnow(), save_history=True)
        s.add(p)
        s.flush()
    return p


# ── 분석 기록 ──
def record_analysis(s, owner: Owner, result: dict) -> Optional[int]:
    """/analyze 응답 dict 를 기록. 기록을 꺼 두었거나 형식이 이상하면 None."""
    if not owner or not get_prefs(s, owner).save_history:
        return None
    primary = result.get("primary") or {}
    code = primary.get("code") or result.get("face_shape")
    if code not in FACE_SHAPES:
        return None
    dist = [{"code": d.get("code"), "name_ko": d.get("name_ko"),
             "probability": float(d.get("probability") or 0)}
            for d in (result.get("distribution") or [])][:5]
    row = AnalysisHistory(
        **owner.cols(), created_at=utcnow(), gender=str(result.get("gender", ""))[:10],
        face_shape_code=code, confidence=primary.get("probability", result.get("confidence")),
        ambiguous=bool(result.get("is_ambiguous", result.get("ambiguous"))), distribution=dist)
    s.add(row)
    s.flush()
    trim_history(s, owner)
    return row.id


def trim_history(s, owner: Owner) -> None:
    old = select(AnalysisHistory.id).where(owner.where(AnalysisHistory)) \
        .order_by(AnalysisHistory.id.desc()).offset(MAX_HISTORY)
    ids = list(s.scalars(old))
    if ids:
        s.execute(delete(AnalysisHistory).where(AnalysisHistory.id.in_(ids)))


def list_history(s, owner: Owner) -> list:
    rows = s.scalars(select(AnalysisHistory).options(joinedload(AnalysisHistory.face_shape))
                     .where(owner.where(AnalysisHistory)).order_by(AnalysisHistory.id.desc()))
    return [{"id": r.id, "created_at": iso(r.created_at), "gender": r.gender,
             "face_shape": r.face_shape_code,
             "name_ko": r.face_shape.name_ko if r.face_shape else None,
             "confidence": r.confidence, "ambiguous": r.ambiguous,
             "distribution": r.distribution} for r in rows]


def delete_history(s, owner: Owner, hid: int) -> bool:
    res = s.execute(delete(AnalysisHistory).where(owner.where(AnalysisHistory), AnalysisHistory.id == hid))
    return res.rowcount > 0


# ── 사진 ──
def clean_image(raw: bytes) -> bytes:
    """이미지인지 확인하고, EXIF 등 메타데이터를 버린 긴 변 1024px JPEG 로 다시 만든다.
    이미지가 아니면 ValueError."""
    from PIL import Image, UnidentifiedImageError
    try:
        img = Image.open(io.BytesIO(raw))
        img.load()
    except (UnidentifiedImageError, OSError) as e:
        raise ValueError("BAD_IMAGE") from e
    if img.format not in ("PNG", "JPEG", "WEBP"):
        raise ValueError("BAD_IMAGE")
    img = img.convert("RGB")
    img.thumbnail((MAX_SIDE, MAX_SIDE))
    out = io.BytesIO()
    img.save(out, "JPEG", quality=92)
    return out.getvalue()


def record_photo(s, owner: Owner, kind: str, title: str, raw: bytes,
                 slug: Optional[str] = None, face_shape: Optional[str] = None,
                 gender: Optional[str] = None, gen_dir: Optional[Path] = None):
    """(SavedPhoto, None) 또는 (None, 에러코드: INVALID / BAD_IMAGE / PHOTOS_FULL). commit 은 부르는 쪽이."""
    title = " ".join((title or "").split())[:200]
    if not owner or kind not in KINDS or not title:
        return None, "INVALID"
    if (slug is not None and not SLUG_RE.match(slug)) or \
       face_shape not in (None, *FACE_SHAPES) or gender not in (None, *GENDERS):
        return None, "INVALID"
    if len(raw) > MAX_UPLOAD:
        return None, "BAD_IMAGE"
    if kind == "synth":
        n = s.scalar(select(func.count()).select_from(SavedPhoto)
                     .where(owner.where(SavedPhoto), SavedPhoto.kind == "synth"))
        if n >= MAX_PHOTOS:
            return None, "PHOTOS_FULL"
    try:
        jpeg = clean_image(raw)
    except ValueError:
        return None, "BAD_IMAGE"

    # 슬러그 → 기존 hairstyles 행. 모르는 슬러그면 연결 없이 제목만 남긴다
    hairstyle_id = s.scalar(select(Hairstyle.id).where(Hairstyle.slug == slug)) if slug else None

    gen_dir = gen_dir or GEN_DIR
    gen_dir.mkdir(exist_ok=True)
    name = secrets.token_hex(12) + ".jpg"        # 추측할 수 없는 이름. 주인 정보를 넣지 않는다
    path = gen_dir / name
    path.write_bytes(jpeg)
    photo = SavedPhoto(**owner.cols(), created_at=utcnow(), kind=kind, title=title,
                       hairstyle_id=hairstyle_id, face_shape_code=face_shape, gender=gender, file_name=name)
    s.add(photo)
    try:
        s.flush()
    except Exception:
        path.unlink(missing_ok=True)             # DB 에 못 넣었으면 파일도 남기지 않는다
        raise
    return photo, None


def photo_json(p: SavedPhoto) -> dict:
    return {"id": p.id, "created_at": iso(p.created_at), "kind": p.kind, "title": p.title,
            "slug": p.hairstyle.slug if p.hairstyle else None,
            "face_shape": p.face_shape_code, "gender": p.gender,
            "image_url": f"/me/photos/{p.id}/image"}


def list_photos(s, owner: Owner, kind: Optional[str] = None) -> list:
    q = select(SavedPhoto).options(joinedload(SavedPhoto.hairstyle)).where(owner.where(SavedPhoto))
    if kind in KINDS:
        q = q.where(SavedPhoto.kind == kind)
    return [photo_json(p) for p in s.scalars(q.order_by(SavedPhoto.id.desc()))]


def get_photo(s, owner: Owner, pid: int, gen_dir: Optional[Path] = None) -> Optional[bytes]:
    name = s.scalar(select(SavedPhoto.file_name).where(owner.where(SavedPhoto), SavedPhoto.id == pid))
    if not name:
        return None
    p = (gen_dir or GEN_DIR) / name
    return p.read_bytes() if p.is_file() else None


def delete_photo(s, owner: Owner, pid: int, gen_dir: Optional[Path] = None) -> bool:
    name = s.scalar(select(SavedPhoto.file_name).where(owner.where(SavedPhoto), SavedPhoto.id == pid))
    if not name:
        return False
    s.execute(delete(SavedPhoto).where(SavedPhoto.id == pid))
    (gen_dir or GEN_DIR).joinpath(name).unlink(missing_ok=True)
    return True


# ── 설정 · 전체 삭제 · 합치기 · 요약 ──
def set_save_history(s, owner: Owner, on: bool) -> None:
    get_prefs(s, owner).save_history = bool(on)


def wipe(s, owner: Owner, gen_dir: Optional[Path] = None) -> None:
    """기록·사진(파일 포함)·설정 삭제. 생성 횟수(users.gen_used)는 건드리지 않는다
    — 지울 때마다 무료 2회가 다시 생기면 안 되므로."""
    if not owner:
        return
    for name in s.scalars(select(SavedPhoto.file_name).where(owner.where(SavedPhoto))):
        (gen_dir or GEN_DIR).joinpath(name).unlink(missing_ok=True)
    s.execute(delete(SavedPhoto).where(owner.where(SavedPhoto)))
    s.execute(delete(AnalysisHistory).where(owner.where(AnalysisHistory)))
    s.execute(delete(VisitorPref).where(owner.where(VisitorPref)))


def merge_guest(s, guest_id: str, user_id: int) -> None:
    """auth_api 가 로그인·가입 직후 같은 트랜잭션 안에서 부른다.
    게스트 행의 주인을 회원으로 바꾼다. 설정은 계정 쪽에 없을 때만 넘기고, 처음 방문일은 더 이른 쪽."""
    if not guest_id:
        return
    g = s.scalar(select(VisitorPref).where(VisitorPref.guest_id == guest_id))
    a = s.scalar(select(VisitorPref).where(VisitorPref.user_id == user_id))
    if g is not None:
        if a is None:
            g.user_id, g.guest_id = user_id, None
        else:
            a.first_seen = min(a.first_seen, g.first_seen)
            s.delete(g)
        s.flush()
    for model in (AnalysisHistory, SavedPhoto):
        s.execute(update(model).where(model.guest_id == guest_id).values(user_id=user_id, guest_id=None))
    trim_history(s, Owner(user_id=user_id))


def summary(s, owner: Owner, user: Optional[User], limit: int) -> dict:
    prefs = get_prefs(s, owner)
    count = lambda model: s.scalar(select(func.count()).select_from(model).where(owner.where(model)))
    used = user.gen_used if user else 0
    return {
        "account": {"name": user.name, "email": user.email, "created_at": iso(user.created_at)} if user else None,
        "guest_tag": None if user else (owner.guest_id or "")[:6].upper(),
        "first_seen": iso(prefs.first_seen),
        "quota": {"limit": limit, "used": min(used, limit), "remaining": max(0, limit - used)},
        "history_count": count(AnalysisHistory),
        "photo_count": count(SavedPhoto),
        "settings": {"save_history": prefs.save_history},
    }


# ═════════════════════════ 라우트 ═════════════════════════
from fastapi import APIRouter, File, Form, Request, Response, UploadFile   # noqa: E402
from fastapi.responses import JSONResponse                                 # noqa: E402
from pydantic import BaseModel                                             # noqa: E402

router = APIRouter()


class SettingsIn(BaseModel):
    save_history: bool


def _err(status: int, code: str) -> JSONResponse:
    return JSONResponse(status_code=status, content={"error": {"code": code}})


def _set_guest_cookie(resp, guest_id: str) -> None:       # gemini_api.me_quota 와 같은 설정
    resp.set_cookie(GUEST_COOKIE, guest_id, max_age=COOKIE_AGE, httponly=True, samesite="lax")


def _owner(request: Request, user: Optional[User] = None):
    """(owner, 새로 발급한 게스트 id 또는 None). 마이페이지로 먼저 들어와도 쿠키가 생기게 한다."""
    owner = current_owner(request, user)
    if owner:
        return owner, None
    gid = secrets.token_urlsafe(16)
    return Owner(guest_id=gid), gid


def _reply(content, new_guest: Optional[str], status: int = 200) -> JSONResponse:
    resp = JSONResponse(content=content, status_code=status, headers={"Cache-Control": "no-store"})
    if new_guest:
        _set_guest_cookie(resp, new_guest)
    return resp


# ── 다른 파일이 부르는 함수 ──
def save_analysis(request: Request, response: Response, result: dict) -> None:
    """web_main.analyze() 끝에서 부른다. 쿠키가 없으면 여기서 발급(첫 방문자의 첫 분석도 기록).
    저장이 실패해도 분석 응답은 막지 않는다."""
    try:
        owner, new_guest = _owner(request)
        if new_guest:
            _set_guest_cookie(response, new_guest)
        with get_session() as s:
            record_analysis(s, owner, result)
            s.commit()
    except Exception as e:
        print(f"[mypage] 분석 기록 실패: {type(e).__name__}")


def save_generated(user_id: int, prompt: str, data: bytes) -> None:
    """gemini_api.generate() 성공 직후 부른다(프롬프트 결과 자동 저장). 실패해도 응답은 막지 않는다."""
    try:
        with get_session() as s:
            _, err = record_photo(s, Owner(user_id=user_id), "prompt", prompt, data)
            if err:
                print(f"[mypage] 생성 결과 저장 안 됨: {err}")
                return
            s.commit()
    except Exception as e:
        print(f"[mypage] 생성 결과 저장 실패: {type(e).__name__}")


# ── 계정 정보 ──
@router.get("/me")
async def me(request: Request):
    from gemini_api import FREE_LIMIT
    user = current_user(request)
    owner, new_guest = _owner(request, user)
    with get_session() as s:
        data = summary(s, owner, user, FREE_LIMIT)
        s.commit()                                   # 처음 온 사람의 설정 행
    return _reply(data, new_guest)


# ── 분석 기록 ──
@router.get("/me/history")
async def me_history(request: Request):
    owner, new_guest = _owner(request)
    with get_session() as s:
        return _reply(list_history(s, owner), new_guest)


@router.delete("/me/history/{hid}")
async def me_history_delete(hid: int, request: Request):
    owner = current_owner(request)
    if not owner:
        return _err(401, "NOT_LOGGED_IN")
    with get_session() as s:
        ok = delete_history(s, owner, hid)
        s.commit()
    return {"deleted": hid} if ok else _err(404, "NOT_FOUND")


# ── 사진 ──
@router.get("/me/photos")
async def me_photos(request: Request, kind: Optional[str] = None):
    owner, new_guest = _owner(request)
    with get_session() as s:
        return _reply(list_photos(s, owner, kind), new_guest)


@router.post("/me/photos")
async def me_photo_add(
    request: Request,
    file: UploadFile = File(...),
    title: str = Form(...),
    slug: Optional[str] = Form(None),
    face_shape: Optional[str] = Form(None),
    gender: Optional[str] = Form(None),
):
    owner, new_guest = _owner(request)
    raw = await file.read(MAX_UPLOAD + 1)
    with get_session() as s:
        photo, err = record_photo(s, owner, "synth", title, raw,
                                  slug or None, face_shape or None, gender or None)
        if err:
            return _err({"PHOTOS_FULL": 409, "BAD_IMAGE": 400}.get(err, 400), err)
        s.commit()
        pid = photo.id
    return _reply({"id": pid, "image_url": f"/me/photos/{pid}/image"}, new_guest, 201)


@router.get("/me/photos/{pid}/image")
async def me_photo_image(pid: int, request: Request):
    owner = current_owner(request)
    with get_session() as s:
        data = get_photo(s, owner, pid) if owner else None
    if not data:
        return _err(404, "NOT_FOUND")
    return Response(content=data, media_type="image/jpeg",
                    headers={"Cache-Control": "private, max-age=3600"})


@router.delete("/me/photos/{pid}")
async def me_photo_delete(pid: int, request: Request):
    owner = current_owner(request)
    if not owner:
        return _err(401, "NOT_LOGGED_IN")
    with get_session() as s:
        ok = delete_photo(s, owner, pid)
        s.commit()
    return {"deleted": pid} if ok else _err(404, "NOT_FOUND")


# ── 보안 설정 ──
@router.patch("/me/settings")
async def me_settings(body: SettingsIn, request: Request):
    owner, new_guest = _owner(request)
    with get_session() as s:
        set_save_history(s, owner, body.save_history)
        s.commit()
    return _reply({"save_history": body.save_history}, new_guest)


@router.delete("/me")
async def me_wipe(request: Request):
    owner = current_owner(request)
    if not owner:
        return _err(401, "NOT_LOGGED_IN")
    with get_session() as s:
        wipe(s, owner)
        s.commit()
    return {"wiped": True}
